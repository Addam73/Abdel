# 📡 Abdel - IPTV Downloader

تطبيق Android لتحميل وتسجيل قنوات IPTV بسهولة

![Android](https://img.shields.io/badge/Android-5.0%2B-green)
![Kotlin](https://img.shields.io/badge/Kotlin-1.9-blue)
![License](https://img.shields.io/badge/License-MIT-purple)

## ✨ الميزات
- ⬇️ تحميل بثوث IPTV بروابط مباشرة
- 📋 إدارة قائمة تحميل كاملة
- 📺 استيراد قوائم M3U تلقائياً
- ⏸ إيقاف واستئناف التحميل
- 🔔 إشعارات عند اكتمال التحميل
- 📱 التشغيل في الخلفية
- 💾 حفظ بصيغ: TS, MP4, MKV, M2TS
- ⚙️ إعدادات متكاملة

## 📲 طريقة التثبيت
1. حمّل ملف APK من قسم [Releases](../../releases)
2. فعّل "تثبيت من مصادر غير معروفة" في إعدادات هاتفك
3. ثبّت التطبيق

## 🛠️ بناء المشروع
```bash
git clone https://github.com/YOUR_USERNAME/Abdel.git
cd Abdel
./gradlew assembleDebug
```

## 📋 المتطلبات
- Android 5.0+ (API 21)
- Android Studio Hedgehog أو أحدث
- JDK 8+

## 📁 هيكل المشروع
```
app/src/main/
├── java/com/abdel/iptvdownloader/
│   ├── ui/
│   │   ├── main/MainActivity.kt
│   │   ├── download/DownloadFragment.kt
│   │   ├── download/DownloadAdapter.kt
│   │   ├── playlist/PlaylistFragment.kt
│   │   └── settings/SettingsFragment.kt
│   ├── service/DownloadService.kt
│   ├── model/Models.kt
│   └── util/M3UParser.kt
└── res/layout/
```

## 🤝 المساهمة
كل مساهمة مرحب بها! افتح Issue أو Pull Request.

## 📄 الرخصة
MIT License - مجاني للجميع
