package com.abdel.iptvdownloader.util

import com.abdel.iptvdownloader.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object M3UParser {

    suspend fun parseFromUrl(urlStr: String): List<Channel> = withContext(Dispatchers.IO) {
        val channels = mutableListOf<Channel>()
        try {
            val url = URL(urlStr)
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            val reader = BufferedReader(InputStreamReader(connection.inputStream))
            parseLines(reader.readLines(), channels)
            connection.disconnect()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        channels
    }

    suspend fun parseFromFile(filePath: String): List<Channel> = withContext(Dispatchers.IO) {
        val channels = mutableListOf<Channel>()
        try {
            val lines = java.io.File(filePath).readLines()
            parseLines(lines, channels)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        channels
    }

    private fun parseLines(lines: List<String>, channels: MutableList<Channel>) {
        if (lines.isEmpty() || !lines[0].trim().startsWith("#EXTM3U")) return

        var currentName = ""
        var currentGroup = ""
        var currentLogo = ""

        for (line in lines) {
            val trimmed = line.trim()
            when {
                trimmed.startsWith("#EXTINF:") -> {
                    currentName = extractAttribute(trimmed, "tvg-name")
                        .ifEmpty { trimmed.substringAfterLast(",").trim() }
                    currentGroup = extractAttribute(trimmed, "group-title")
                    currentLogo = extractAttribute(trimmed, "tvg-logo")
                }
                trimmed.startsWith("http") || trimmed.startsWith("rtmp") || trimmed.startsWith("rtsp") -> {
                    if (currentName.isNotEmpty()) {
                        channels.add(Channel(
                            name = currentName,
                            url = trimmed,
                            group = currentGroup,
                            logo = currentLogo
                        ))
                    }
                    currentName = ""
                    currentGroup = ""
                    currentLogo = ""
                }
            }
        }
    }

    private fun extractAttribute(line: String, attr: String): String {
        val pattern = Regex("""$attr="([^"]*)"""")
        return pattern.find(line)?.groupValues?.get(1) ?: ""
    }
}
