package com.abdel.iptvdownloader.ui.download

import android.view.*
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.abdel.iptvdownloader.R
import com.abdel.iptvdownloader.model.DownloadItem
import com.abdel.iptvdownloader.model.DownloadStatus
import com.google.android.material.button.MaterialButton

class DownloadAdapter(
    private val items: MutableList<DownloadItem>,
    private val onPause: (DownloadItem) -> Unit,
    private val onResume: (DownloadItem) -> Unit,
    private val onDelete: (DownloadItem) -> Unit
) : RecyclerView.Adapter<DownloadAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tv_channel_name)
        val tvUrl: TextView = view.findViewById(R.id.tv_url)
        val tvStatus: TextView = view.findViewById(R.id.tv_status)
        val tvProgress: TextView = view.findViewById(R.id.tv_progress)
        val tvSpeed: TextView = view.findViewById(R.id.tv_speed)
        val progressBar: ProgressBar = view.findViewById(R.id.progress_bar)
        val btnAction: MaterialButton = view.findViewById(R.id.btn_action)
        val btnDelete: MaterialButton = view.findViewById(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_download, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvName.text = item.channelName
        holder.tvUrl.text = item.url
        holder.tvProgress.text = "${item.progress}%"
        holder.tvSpeed.text = "${item.speedKBps} KB/s"
        holder.progressBar.progress = item.progress

        when (item.status) {
            DownloadStatus.DOWNLOADING -> {
                holder.tvStatus.text = "● جاري التحميل"
                holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.context, android.R.color.holo_blue_light))
                holder.btnAction.text = "⏸ إيقاف"
                holder.btnAction.setOnClickListener { onPause(item); item.status = DownloadStatus.PAUSED; notifyItemChanged(position) }
            }
            DownloadStatus.PAUSED -> {
                holder.tvStatus.text = "⏸ موقوف"
                holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.context, android.R.color.darker_gray))
                holder.btnAction.text = "▶ استئناف"
                holder.btnAction.setOnClickListener { onResume(item); item.status = DownloadStatus.DOWNLOADING; notifyItemChanged(position) }
            }
            DownloadStatus.COMPLETED -> {
                holder.tvStatus.text = "✓ مكتمل"
                holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.context, android.R.color.holo_green_light))
                holder.btnAction.text = "✓ تم"
                holder.btnAction.isEnabled = false
            }
            DownloadStatus.ERROR -> {
                holder.tvStatus.text = "✕ خطأ"
                holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.context, android.R.color.holo_red_light))
                holder.btnAction.text = "↺ إعادة"
                holder.btnAction.setOnClickListener { onResume(item); notifyItemChanged(position) }
            }
            DownloadStatus.QUEUED -> {
                holder.tvStatus.text = "⏳ في الانتظار"
                holder.tvStatus.setTextColor(ContextCompat.getColor(holder.itemView.context, android.R.color.holo_orange_light))
                holder.btnAction.text = "⏸"
                holder.btnAction.isEnabled = false
            }
        }

        holder.btnDelete.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount() = items.size
}
