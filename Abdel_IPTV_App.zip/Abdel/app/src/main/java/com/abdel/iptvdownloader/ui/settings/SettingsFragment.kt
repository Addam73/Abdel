package com.abdel.iptvdownloader.ui.settings

import android.content.SharedPreferences
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.preference.PreferenceManager
import com.abdel.iptvdownloader.R
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsFragment : Fragment() {

    private lateinit var prefs: SharedPreferences

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_settings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        prefs = PreferenceManager.getDefaultSharedPreferences(requireContext())

        val switchWifiOnly = view.findViewById<SwitchMaterial>(R.id.switch_wifi_only)
        val switchAutoRetry = view.findViewById<SwitchMaterial>(R.id.switch_auto_retry)
        val switchNotify = view.findViewById<SwitchMaterial>(R.id.switch_notify)
        val switchBackground = view.findViewById<SwitchMaterial>(R.id.switch_background)
        val spinnerFormat = view.findViewById<Spinner>(R.id.spinner_default_format)
        val spinnerConcurrent = view.findViewById<Spinner>(R.id.spinner_concurrent)

        switchWifiOnly.isChecked = prefs.getBoolean("wifi_only", false)
        switchAutoRetry.isChecked = prefs.getBoolean("auto_retry", true)
        switchNotify.isChecked = prefs.getBoolean("notify_complete", true)
        switchBackground.isChecked = prefs.getBoolean("background_service", true)

        switchWifiOnly.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("wifi_only", v).apply() }
        switchAutoRetry.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("auto_retry", v).apply() }
        switchNotify.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("notify_complete", v).apply() }
        switchBackground.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("background_service", v).apply() }

        val formats = arrayOf("TS", "MP4", "MKV", "M2TS")
        spinnerFormat.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, formats)
        spinnerFormat.setSelection(formats.indexOf(prefs.getString("default_format", "TS")).coerceAtLeast(0))
        spinnerFormat.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("default_format", formats[pos]).apply()
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }

        val concurrentOptions = arrayOf("1", "2", "3", "4")
        spinnerConcurrent.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, concurrentOptions)
        spinnerConcurrent.setSelection(prefs.getInt("concurrent_downloads", 1).coerceIn(0, 3))
        spinnerConcurrent.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("concurrent_downloads", pos).apply()
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
    }
}
