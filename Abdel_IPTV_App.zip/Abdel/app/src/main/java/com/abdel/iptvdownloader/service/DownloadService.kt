package com.abdel.iptvdownloader.service

import android.app.*
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.abdel.iptvdownloader.R
import com.abdel.iptvdownloader.model.DownloadItem
import com.abdel.iptvdownloader.model.DownloadStatus
import com.abdel.iptvdownloader.ui.main.MainActivity
import kotlinx.coroutines.*
import java.io.*
import java.net.HttpURLConnection
import java.net.URL

class DownloadService : Service() {

    private val binder = DownloadBinder()
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val activeJobs = mutableMapOf<String, Job>()
    private val downloadListeners = mutableListOf<DownloadListener>()

    companion object {
        const val CHANNEL_ID = "abdel_download_channel"
        const val NOTIFICATION_ID = 1
        const val ACTION_START = "com.abdel.iptvdownloader.START"
        const val ACTION_PAUSE = "com.abdel.iptvdownloader.PAUSE"
        const val ACTION_RESUME = "com.abdel.iptvdownloader.RESUME"
        const val ACTION_CANCEL = "com.abdel.iptvdownloader.CANCEL"
        const val EXTRA_DOWNLOAD_ID = "download_id"
        const val BUFFER_SIZE = 8192
    }

    interface DownloadListener {
        fun onProgressUpdate(item: DownloadItem)
        fun onDownloadComplete(item: DownloadItem)
        fun onDownloadError(item: DownloadItem, error: String)
    }

    inner class DownloadBinder : Binder() {
        fun getService(): DownloadService = this@DownloadService
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Abdel IPTV", "الخدمة جاهزة"))
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    fun addListener(listener: DownloadListener) {
        downloadListeners.add(listener)
    }

    fun removeListener(listener: DownloadListener) {
        downloadListeners.remove(listener)
    }

    fun startDownload(item: DownloadItem, outputDir: File) {
        if (activeJobs.containsKey(item.id)) return
        item.status = DownloadStatus.DOWNLOADING
        val job = serviceScope.launch {
            downloadStream(item, outputDir)
        }
        activeJobs[item.id] = job
    }

    fun pauseDownload(itemId: String) {
        activeJobs[itemId]?.cancel()
        activeJobs.remove(itemId)
    }

    fun cancelDownload(itemId: String) {
        activeJobs[itemId]?.cancel()
        activeJobs.remove(itemId)
    }

    private suspend fun downloadStream(item: DownloadItem, outputDir: File) {
        val outputFile = File(outputDir, "${item.channelName.replace(" ", "_")}_${System.currentTimeMillis()}.${item.format}")
        item.filePath = outputFile.absolutePath

        var connection: HttpURLConnection? = null
        var inputStream: InputStream? = null
        var outputStream: FileOutputStream? = null

        try {
            val url = URL(item.url)
            connection = url.openConnection() as HttpURLConnection
            connection.apply {
                connectTimeout = 15000
                readTimeout = 30000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "Abdel-IPTV-Downloader/1.0")
            }
            connection.connect()

            if (connection.responseCode !in 200..299) {
                throw IOException("HTTP ${connection.responseCode}: ${connection.responseMessage}")
            }

            val contentLength = connection.contentLengthLong
            item.totalBytes = contentLength

            inputStream = BufferedInputStream(connection.inputStream, BUFFER_SIZE)
            outputStream = FileOutputStream(outputFile)

            val buffer = ByteArray(BUFFER_SIZE)
            var bytesRead: Int
            var downloadedBytes = 0L
            var lastSpeedCheck = System.currentTimeMillis()
            var bytesAtLastCheck = 0L

            val durationMs = if (item.durationMinutes > 0) item.durationMinutes * 60 * 1000L else Long.MAX_VALUE
            val startTime = System.currentTimeMillis()

            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                if (!isActive) {
                    item.status = DownloadStatus.PAUSED
                    break
                }
                if (System.currentTimeMillis() - startTime >= durationMs) break

                outputStream.write(buffer, 0, bytesRead)
                downloadedBytes += bytesRead
                item.downloadedBytes = downloadedBytes

                val now = System.currentTimeMillis()
                if (now - lastSpeedCheck >= 1000) {
                    val elapsed = (now - lastSpeedCheck) / 1000.0
                    item.speedKBps = ((downloadedBytes - bytesAtLastCheck) / elapsed / 1024).toLong()
                    bytesAtLastCheck = downloadedBytes
                    lastSpeedCheck = now
                }

                if (contentLength > 0) {
                    item.progress = (downloadedBytes * 100 / contentLength).toInt()
                }

                withContext(Dispatchers.Main) {
                    downloadListeners.forEach { it.onProgressUpdate(item) }
                    updateNotification("تحميل: ${item.channelName}", "${item.progress}% - ${item.speedKBps} KB/s")
                }
            }

            if (item.status != DownloadStatus.PAUSED) {
                item.status = DownloadStatus.COMPLETED
                item.progress = 100
                withContext(Dispatchers.Main) {
                    downloadListeners.forEach { it.onDownloadComplete(item) }
                    sendCompletionNotification(item)
                }
            }

        } catch (e: CancellationException) {
            item.status = DownloadStatus.PAUSED
        } catch (e: Exception) {
            item.status = DownloadStatus.ERROR
            item.errorMessage = e.message ?: "خطأ غير معروف"
            withContext(Dispatchers.Main) {
                downloadListeners.forEach { it.onDownloadError(item, item.errorMessage) }
            }
        } finally {
            try {
                inputStream?.close()
                outputStream?.flush()
                outputStream?.close()
                connection?.disconnect()
            } catch (e: IOException) { /* ignore */ }
            activeJobs.remove(item.id)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Abdel IPTV Downloader",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعارات تحميل IPTV"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, content: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(title: String, content: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm?.notify(NOTIFICATION_ID, buildNotification(title, content))
    }

    private fun sendCompletionNotification(item: DownloadItem) {
        val nm = getSystemService(NotificationManager::class.java)
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("اكتمل التحميل ✓")
            .setContentText(item.channelName)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setAutoCancel(true)
            .build()
        nm?.notify(item.id.hashCode(), notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
