package com.abdel.iptvdownloader.model

import java.util.UUID

enum class DownloadStatus {
    QUEUED, DOWNLOADING, PAUSED, COMPLETED, ERROR
}

data class DownloadItem(
    val id: String = UUID.randomUUID().toString(),
    val channelName: String,
    val url: String,
    val format: String = "ts",
    val durationMinutes: Int = 0,
    var status: DownloadStatus = DownloadStatus.QUEUED,
    var progress: Int = 0,
    var speedKBps: Long = 0L,
    var downloadedBytes: Long = 0L,
    var totalBytes: Long = 0L,
    var filePath: String = "",
    var errorMessage: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class Playlist(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val url: String,
    val localPath: String = "",
    val channelCount: Int = 0,
    val addedAt: Long = System.currentTimeMillis()
)

data class Channel(
    val name: String,
    val url: String,
    val group: String = "",
    val logo: String = ""
)
