package com.abdel.iptvdownloader.ui.download

import android.content.*
import android.os.*
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.*
import com.abdel.iptvdownloader.R
import com.abdel.iptvdownloader.model.*
import com.abdel.iptvdownloader.service.DownloadService
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class DownloadFragment : Fragment(), DownloadService.DownloadListener {

    private lateinit var adapter: DownloadAdapter
    private val downloads = mutableListOf<DownloadItem>()
    private var downloadService: DownloadService? = null
    private var bound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as DownloadService.DownloadBinder
            downloadService = binder.getService()
            downloadService?.addListener(this@DownloadFragment)
            bound = true
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            bound = false
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_download, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etUrl = view.findViewById<TextInputEditText>(R.id.et_url)
        val etName = view.findViewById<TextInputEditText>(R.id.et_channel_name)
        val etDuration = view.findViewById<TextInputEditText>(R.id.et_duration)
        val spinnerFormat = view.findViewById<Spinner>(R.id.spinner_format)
        val btnAdd = view.findViewById<MaterialButton>(R.id.btn_add_download)
        val btnPauseAll = view.findViewById<MaterialButton>(R.id.btn_pause_all)
        val btnClearDone = view.findViewById<MaterialButton>(R.id.btn_clear_done)
        val rvDownloads = view.findViewById<RecyclerView>(R.id.rv_downloads)

        val formats = arrayOf("TS", "MP4", "MKV", "M2TS")
        spinnerFormat.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, formats)

        adapter = DownloadAdapter(
            downloads,
            onPause = { item -> downloadService?.pauseDownload(item.id) },
            onResume = { item ->
                val dir = getOutputDir()
                downloadService?.startDownload(item, dir)
            },
            onDelete = { item ->
                downloadService?.cancelDownload(item.id)
                downloads.remove(item)
                adapter.notifyDataSetChanged()
            }
        )
        rvDownloads.layoutManager = LinearLayoutManager(requireContext())
        rvDownloads.adapter = adapter

        btnAdd.setOnClickListener {
            val url = etUrl.text.toString().trim()
            val name = etName.text.toString().trim().ifEmpty { "قناة ${downloads.size + 1}" }
            val format = formats[spinnerFormat.selectedItemPosition].lowercase()
            val duration = etDuration.text.toString().trim().toIntOrNull() ?: 0
            if (url.isEmpty()) { Toast.makeText(context, "الرجاء إدخال رابط البث", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val item = DownloadItem(channelName = name, url = url, format = format, durationMinutes = duration)
            downloads.add(0, item)
            adapter.notifyItemInserted(0)
            rvDownloads.scrollToPosition(0)
            etUrl.text?.clear()
            etName.text?.clear()
            downloadService?.startDownload(item, getOutputDir())
        }

        btnPauseAll.setOnClickListener {
            downloads.filter { it.status == DownloadStatus.DOWNLOADING }.forEach {
                downloadService?.pauseDownload(it.id)
                it.status = DownloadStatus.PAUSED
            }
            adapter.notifyDataSetChanged()
        }

        btnClearDone.setOnClickListener {
            downloads.removeAll { it.status == DownloadStatus.COMPLETED }
            adapter.notifyDataSetChanged()
        }
    }

    private fun getOutputDir(): android.io.File {
        val dir = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            requireContext().getExternalFilesDir("IPTV_Downloads")
        } else {
            android.io.File(Environment.getExternalStorageDirectory(), "IPTV_Downloads")
        }
        dir?.mkdirs()
        return dir ?: requireContext().filesDir
    }

    override fun onStart() {
        super.onStart()
        Intent(requireContext(), DownloadService::class.java).also {
            requireContext().bindService(it, connection, Context.BIND_AUTO_CREATE)
        }
    }

    override fun onStop() {
        super.onStop()
        if (bound) {
            downloadService?.removeListener(this)
            requireContext().unbindService(connection)
            bound = false
        }
    }

    override fun onProgressUpdate(item: DownloadItem) {
        val index = downloads.indexOfFirst { it.id == item.id }
        if (index >= 0) adapter.notifyItemChanged(index)
    }

    override fun onDownloadComplete(item: DownloadItem) {
        val index = downloads.indexOfFirst { it.id == item.id }
        if (index >= 0) adapter.notifyItemChanged(index)
        Toast.makeText(context, "اكتمل: ${item.channelName}", Toast.LENGTH_SHORT).show()
    }

    override fun onDownloadError(item: DownloadItem, error: String) {
        val index = downloads.indexOfFirst { it.id == item.id }
        if (index >= 0) adapter.notifyItemChanged(index)
        Toast.makeText(context, "خطأ: $error", Toast.LENGTH_SHORT).show()
    }
}
