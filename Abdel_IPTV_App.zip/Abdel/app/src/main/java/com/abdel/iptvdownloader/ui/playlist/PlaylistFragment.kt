package com.abdel.iptvdownloader.ui.playlist

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.*
import com.abdel.iptvdownloader.R
import com.abdel.iptvdownloader.model.Channel
import com.abdel.iptvdownloader.util.M3UParser
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class PlaylistFragment : Fragment() {

    private lateinit var channelAdapter: ChannelAdapter
    private val channels = mutableListOf<Channel>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_playlist, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etSearch = view.findViewById<TextInputEditText>(R.id.et_search)
        val btnImport = view.findViewById<MaterialButton>(R.id.btn_import_m3u)
        val rvChannels = view.findViewById<RecyclerView>(R.id.rv_channels)
        val tvCount = view.findViewById<TextView>(R.id.tv_channel_count)
        val progressBar = view.findViewById<ProgressBar>(R.id.progress_import)

        channelAdapter = ChannelAdapter(channels) { channel ->
            showDownloadDialog(channel)
        }
        rvChannels.layoutManager = LinearLayoutManager(requireContext())
        rvChannels.adapter = channelAdapter

        etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                val query = s.toString().lowercase()
                channelAdapter.filter(channels.filter { it.name.lowercase().contains(query) })
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        btnImport.setOnClickListener {
            showImportDialog(progressBar, tvCount)
        }
    }

    private fun showImportDialog(progressBar: ProgressBar, tvCount: TextView) {
        val input = EditText(requireContext()).apply {
            hint = "http://server:port/playlist.m3u"
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        AlertDialog.Builder(requireContext())
            .setTitle("استيراد قائمة M3U")
            .setView(input)
            .setPositiveButton("استيراد") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) {
                    progressBar.visibility = View.VISIBLE
                    lifecycleScope.launch {
                        val parsed = M3UParser.parseFromUrl(url)
                        channels.clear()
                        channels.addAll(parsed)
                        channelAdapter.filter(channels)
                        tvCount.text = "${channels.size} قناة"
                        progressBar.visibility = View.GONE
                        Toast.makeText(context, "تم استيراد ${channels.size} قناة", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showDownloadDialog(channel: Channel) {
        AlertDialog.Builder(requireContext())
            .setTitle("تحميل قناة")
            .setMessage("هل تريد تحميل: ${channel.name}؟")
            .setPositiveButton("تحميل") { _, _ ->
                Toast.makeText(context, "تم إضافة ${channel.name} للتحميل", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}

class ChannelAdapter(
    private var items: List<Channel>,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tv_ch_name)
        val tvGroup: TextView = view.findViewById(R.id.tv_ch_group)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ch = items[position]
        holder.tvName.text = ch.name
        holder.tvGroup.text = ch.group.ifEmpty { "بدون مجموعة" }
        holder.itemView.setOnClickListener { onClick(ch) }
    }

    override fun getItemCount() = items.size

    fun filter(filtered: List<Channel>) {
        items = filtered
        notifyDataSetChanged()
    }
}
