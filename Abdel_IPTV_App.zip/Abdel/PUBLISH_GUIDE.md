# 📘 دليل نشر تطبيق Abdel على GitHub

## الخطوة 1 — إنشاء حساب GitHub مجاني

1. اذهب إلى: https://github.com/signup
2. أدخل:
   - Email (بريدك الإلكتروني)
   - Password (كلمة مرور)
   - Username (اسم المستخدم - سيظهر في رابط التطبيق)
3. اضغط "Create account" وأكّد بريدك

---

## الخطوة 2 — إنشاء Repository جديد

1. سجّل دخولك على GitHub
2. اضغط الزر "+" في الأعلى ← "New repository"
3. اكتب:
   - Repository name: **Abdel**
   - Description: تطبيق IPTV Downloader للأندرويد
   - اختر: **Public** (ليكون مجانياً وظاهراً للجميع)
   - ✅ Add a README file
4. اضغط "Create repository"

---

## الخطوة 3 — رفع الكود

### الطريقة السهلة (رفع مباشر من المتصفح):

1. افتح الـ Repository الذي أنشأته
2. اضغط "Add file" ← "Upload files"
3. اسحب مجلد **Abdel** كاملاً وأفلته
4. اكتب في "Commit changes": `Initial commit - Abdel IPTV Downloader`
5. اضغط "Commit changes"

### الطريقة الاحترافية (Git):
```bash
git init
git add .
git commit -m "Initial commit - Abdel IPTV Downloader"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/Abdel.git
git push -u origin main
```

---

## الخطوة 4 — نشر ملف APK كـ Release

1. في Android Studio: Build → Generate Signed Bundle/APK
2. اختر APK → Next → أنشئ Keystore → Build
3. على GitHub: اضغط "Releases" ← "Create a new release"
4. اكتب:
   - Tag: `v1.0.0`
   - Title: `Abdel v1.0 - أول إصدار`
5. ارفع ملف APK في "Attach binaries"
6. اضغط "Publish release"

---

## ✅ النتيجة

رابط تطبيقك سيكون:
```
https://github.com/YOUR_USERNAME/Abdel
```

الناس يقدرون يحملون APK مباشرة من صفحة Releases!

---

## 📌 ملاحظات مهمة

- GitHub مجاني تماماً للمشاريع العامة (Public)
- يمكنك تحديث الكود في أي وقت
- يمكنك إضافة صور وشرح للتطبيق في README
